"""Offline administrator tool for Bake Groups Tool licenses.

The private key must stay outside the plugin and repository. The runtime only
needs the matching public key. Requires the administrator's Python environment
to have the ``cryptography`` package installed.
"""
from __future__ import print_function

import argparse
import base64
import datetime
import json
import os
import sys

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


PRODUCT = "Bake Groups Tool"
SCHEMA_VERSION = 1


def canonical(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def load_private_key(path):
    with open(path, "rb") as stream:
        return serialization.load_pem_private_key(stream.read(), password=None)


def sign_mapping(private_key, mapping):
    signed = dict(mapping)
    signed["signature"] = base64.b64encode(private_key.sign(canonical(mapping))).decode("ascii")
    return signed


def write_json(path, value):
    parent = os.path.dirname(os.path.abspath(path))
    if not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=True, sort_keys=True, indent=2)
        stream.write("\n")


def command_keygen(args):
    private_key = Ed25519PrivateKey.generate()
    private_bytes = private_key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    public_bytes = private_key.public_key().public_bytes(
        serialization.Encoding.Raw,
        serialization.PublicFormat.Raw,
    )
    parent = os.path.dirname(os.path.abspath(args.private))
    if not os.path.isdir(parent):
        os.makedirs(parent)
    with open(args.private, "wb") as stream:
        stream.write(private_bytes)
    with open(args.public, "w", encoding="ascii", newline="\n") as stream:
        stream.write(base64.b64encode(public_bytes).decode("ascii") + "\n")
    print("Private key: {}".format(os.path.abspath(args.private)))
    print("Public key: {}".format(os.path.abspath(args.public)))


def command_issue(args):
    private_key = load_private_key(args.private)
    machine_hash = args.machine_hash.strip().lower()
    if len(machine_hash) != 64 or any(char not in "0123456789abcdef" for char in machine_hash):
        raise SystemExit("machine_hash must be the 64-character machine code shown by the plugin")
    now = int(datetime.datetime.now(datetime.timezone.utc).timestamp())
    license_data = {
        "schema_version": SCHEMA_VERSION,
        "product": PRODUCT,
        "license_id": args.license_id,
        "machine_hash": machine_hash,
        "issued_at": now,
        "expires_at": (now + args.days * 86400) if args.days else None,
        "offline_days": 14,
    }
    write_json(args.output, sign_mapping(private_key, license_data))
    print("License written: {}".format(os.path.abspath(args.output)))


def command_status(args):
    private_key = load_private_key(args.private)
    revoked = []
    if os.path.isfile(args.input):
        with open(args.input, "r", encoding="utf-8-sig") as stream:
            old = json.load(stream)
        revoked = list(old.get("revoked", []))
    for license_id in args.revoke:
        if license_id not in revoked:
            revoked.append(license_id)
    for license_id in args.unrevoke:
        revoked = [item for item in revoked if item != license_id]
    unsigned = {
        "schema_version": SCHEMA_VERSION,
        "product": PRODUCT,
        "updated_at": int(datetime.datetime.now(datetime.timezone.utc).timestamp()),
        "revoked": sorted(set(revoked)),
    }
    write_json(args.output, sign_mapping(private_key, unsigned))
    print("Status written: {}".format(os.path.abspath(args.output)))


def main(argv=None):
    parser = argparse.ArgumentParser(description="Bake Groups Tool license administrator")
    subparsers = parser.add_subparsers(dest="command")
    keygen = subparsers.add_parser("keygen")
    keygen.add_argument("--private", required=True)
    keygen.add_argument("--public", required=True)
    keygen.set_defaults(handler=command_keygen)
    issue = subparsers.add_parser("issue")
    issue.add_argument("--private", required=True)
    issue.add_argument("--license-id", required=True)
    issue.add_argument("--machine-hash", required=True)
    issue.add_argument("--output", required=True)
    issue.add_argument("--days", type=int, default=0)
    issue.set_defaults(handler=command_issue)
    status = subparsers.add_parser("status")
    status.add_argument("--private", required=True)
    status.add_argument("--input", required=True)
    status.add_argument("--output", required=True)
    status.add_argument("--revoke", action="append", default=[])
    status.add_argument("--unrevoke", action="append", default=[])
    status.set_defaults(handler=command_status)
    args = parser.parse_args(argv)
    if not getattr(args, "handler", None):
        parser.print_help()
        return 2
    args.handler(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
