# License administration

Keep the Ed25519 private key outside this repository. Only the public key is
shipped in the plugin. The public status file may be hosted in the separate
`Bake-Groups-License-Status` repository.

Issue a machine-bound license:

```powershell
python tools/license_admin.py issue `
  --private D:\Bake_Groups_License_Keys\ed25519_private.pem `
  --license-id CUSTOMER-001 `
  --machine-hash MACHINE_CODE_FROM_PLUGIN `
  --output CUSTOMER-001.json
```

Revoke a license by editing the signed status file:

```powershell
python tools/license_admin.py status `
  --private D:\Bake_Groups_License_Keys\ed25519_private.pem `
  --input status.json `
  --output status.json `
  --revoke CUSTOMER-001
```
