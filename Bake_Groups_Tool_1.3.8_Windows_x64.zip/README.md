# Bake Groups Tool 发布框架

这个目录提供一套面向 Windows / Autodesk Maya 的私有 GitHub 仓库发布框架。它负责生成可安装 ZIP、文件校验清单、`UPDATE_PACKAGE.json`，并通过 GitHub Releases 发布稳定版本。

仓库应保持为 **Private**，不能依赖匿名 `raw.githubusercontent.com` 下载。客户端应使用只读 fine-grained PAT：

1. 通过 GitHub Contents API 读取 `updates/stable.json`，请求头使用 `Accept: application/vnd.github.raw+json`。
2. 请求 `stable.json` 中的 `release_api_url`，找到名称等于 `asset_name` 的资源。
3. 请求该资源的 `url`，使用 `Accept: application/octet-stream` 下载 ZIP。
4. 下载完成后校验 `asset_sha256` 和 `asset_size`，解压后再校验 `UPDATE_PACKAGE.json`。

## 预期仓库结构

```text
.
|-- plugin/
|   `-- Bake_Groups/
|-- installer/
|-- scripts/
|   `-- build-release.ps1
|-- schemas/
|   `-- UPDATE_PACKAGE.schema.json
|-- examples/
|   `-- UPDATE_PACKAGE.json
|-- updates/
|   `-- stable.json
|-- docs/
|   `-- RELEASING.md
`-- .github/workflows/release.yml
```

## 本地构建

```powershell
.\scripts\build-release.ps1 `
  -Version 1.3.8 `
  -RuntimeVersion 1.3.8 `
  -Owner YOUR_GITHUB_OWNER `
  -Repository Bake-Groups-Tool
```

产物写入 `dist/`。完整发布流程见 `docs/RELEASING.md`。

## 令牌安全

客户端下载只需要对指定私有仓库的只读权限。创建 fine-grained PAT 时仅选择目标仓库，并将 `Contents` 设置为 `Read-only`；`Metadata` 保持 GitHub 自动授予的只读权限。PAT 不得提交到 Git、写入 `stable.json`、打包进 ZIP、记录到日志，或保存在 Maya 场景和 `optionVar` 中。插件会在本机使用 Windows DPAPI（当前 Windows 用户）保存加密凭据。

GitHub Actions 不使用个人 PAT。工作流通过仓库自动提供的短期 `GITHUB_TOKEN` 创建 Release 并更新 `updates/stable.json`。
