# 发布 Bake Groups Tool

## 一次性设置

1. 将仓库设置为 Private。
2. 把 `plugin/Bake_Groups`、`installer` 和本框架文件提交到默认分支。
3. 在仓库的 Actions 设置中允许工作流使用 `Read and write permissions`，或保留工作流声明的 `contents: write` 权限。
4. 确认默认分支保护规则允许 `github-actions[bot]` 更新 `updates/stable.json`。若规则要求 Pull Request，应改为由工作流创建 PR，不能绕过保护。
5. 不要在仓库 Secrets 中保存客户端 PAT；发布工作流只使用短期 `GITHUB_TOKEN`。

## 发布前检查

1. 更新 `plugin/Bake_Groups/active_version.json` 和代码中的版本号。
2. 确认 `plugin/Bake_Groups/versions/<runtime>` 存在。
3. 确认 Maya 2022–2027 六个目录都包含对应的 `bg_math_core.pyd`。
4. 更新安装说明和变更记录。
5. 在实际支持的 Maya 版本中完成启动和主要工作流测试。
6. 本地运行一次构建脚本，并核对 `dist/stable.json`、ZIP SHA256 和 ZIP 内的 `UPDATE_PACKAGE.json`。

## 本地构建

```powershell
.\scripts\build-release.ps1 `
  -Version 1.3.8 `
  -RuntimeVersion 1.3.8 `
  -Owner YOUR_GITHUB_OWNER `
  -Repository Bake-Groups-Tool
```

构建脚本不会修改源目录。它会在 `dist/` 中生成：

- `Bake_Groups_Tool_<version>_Windows_x64.zip`
- 同名 `.zip.sha256`
- 工作流用于更新稳定通道的 `stable.json`

## 自动发布

稳定版使用 `v<version>` 标签，例如：

```powershell
git tag v1.3.8
git push origin v1.3.8
```

工作流会执行以下操作：

1. 从标签对应的提交构建 ZIP。
2. 创建 GitHub Release；重复运行时覆盖同名资源。
3. 使用 `GITHUB_TOKEN` 调 Contents API，把默认分支的 `updates/stable.json` 更新为新版本。

也可以手动运行 `Publish stable release` 工作流并输入标签。发布资源成功但稳定通道更新失败时，不要再次改版本；修复分支权限后重跑同一标签即可。

## 私有仓库客户端访问

为每个需要更新的用户创建或让其自行创建 fine-grained PAT：

- Resource owner：仓库所属个人或组织。
- Repository access：仅选择 Bake Groups 仓库。
- Repository permissions：`Contents: Read-only`。
- Expiration：选择尽可能短且可维护的期限。

客户端读取稳定通道：

```text
GET https://api.github.com/repos/OWNER/REPOSITORY/contents/updates/stable.json?ref=main
Authorization: Bearer <FINE_GRAINED_PAT>
Accept: application/vnd.github.raw+json
X-GitHub-Api-Version: 2022-11-28
User-Agent: Bake-Groups-Updater
```

随后读取 `release_api_url`，从响应的 `assets` 数组中找到 `name == asset_name` 的项，再下载其 API `url`：

```text
GET <assets[].url>
Authorization: Bearer <FINE_GRAINED_PAT>
Accept: application/octet-stream
X-GitHub-Api-Version: 2022-11-28
User-Agent: Bake-Groups-Updater
```

不要直接依赖 `browser_download_url`，也不要在私有仓库中使用匿名 raw URL。下载后必须先校验稳定清单中的 ZIP 大小和 SHA256，再解压并校验 `UPDATE_PACKAGE.json` 中的每个插件文件。

## PAT 存储原则

PAT 是用户凭据，不属于插件配置或发布数据。仓库必须保持为 Private。插件当前使用 Windows DPAPI（当前用户）加密保存令牌，并只在发起请求时读取；令牌不会进入安装包、Maya 场景、`optionVar` 或日志。开发环境可临时使用进程级环境变量，但不得把令牌写入：

- Git 仓库、GitHub Issue 或 Actions 日志
- `stable.json`、`UPDATE_PACKAGE.json`、ZIP 或校验文件
- Maya 场景、脚本节点、`optionVar` 或明文偏好文件

发现泄露时立即在 GitHub 撤销令牌，并重新生成权限更小的新令牌。
